var siteinfo = {
  name: "ChatGPT专业版",
  siteroot: "https://chat-ai.kaifa.cc/index.php?s=/api", // 必填: api地址
  uniacid: "10001"
};
module.exports = siteinfo;