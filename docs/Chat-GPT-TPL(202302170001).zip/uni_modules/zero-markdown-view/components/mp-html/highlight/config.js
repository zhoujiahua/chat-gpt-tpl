export default {
  copyByLongPress: true, // 是否需要长按代码块时显示复制代码内容菜单
  showLanguageName: false, // 是否在代码块右上角显示语言的名称
  showLineNumber: false // 是否显示行号
}
